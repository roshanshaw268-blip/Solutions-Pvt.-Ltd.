SIMMO SOLUTIONS — WEBSITE

Files:
- index.html
- style.css

How to use:
1. Open index.html in a browser to preview.
2. Replace hello@simmosolutions.com with the official company email.
3. Replace the WhatsApp placeholder number in index.html.
4. Replace demo portfolio items with real projects as they are completed.
5. Deploy the folder to Netlify, GitHub Pages, Vercel, or another static host.

This is a portfolio/marketing site, not yet a legal company-registration document.
